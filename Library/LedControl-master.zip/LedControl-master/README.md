LedControl
==========
LedControl is an [Arduino](http://arduino.cc) library for MAX7219 and MAX7221 Led display drivers.

Documentation
-------------
There is a tutorial for the library on the [Arduino Playground](http://playground.arduino.cc/Main/LedControl)

Download
--------
The lastest binary version of the Library is always available from the 
[LedControl Release Page](https://github.com/wayoda/LedControl/releases) 


Install
-------
The library can be installed using the [standard Arduino library install procedure](http://arduino.cc/en/Guide/Libraries#.UwxndHX5PtY)  







