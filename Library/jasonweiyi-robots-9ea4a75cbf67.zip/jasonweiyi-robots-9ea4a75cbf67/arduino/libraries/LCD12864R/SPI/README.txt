The library includes the following two files:
(1) LCD12864RSPI.h
(2) LCD12864RSPI.cpp


